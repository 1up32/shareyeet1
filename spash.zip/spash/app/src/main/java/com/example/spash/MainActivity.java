package com.example.spash;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    private SeekBar seekWord;
    private EditText editTextInput;
    private TextView textViewOutput;
    private String[] num;
    private int numWords;
    private ImageView imageViewSplash;
    private ImageView imageViewBackground;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextInput = findViewById(R.id.editTextInput);
        textViewOutput = findViewById(R.id.textViewOutput);
        seekWord = findViewById(R.id.seekBarChooseWord);
        imageViewSplash = findViewById(R.id.imageViewSplash);
        imageViewBackground = findViewById(R.id.imageViewBackground);

        textViewOutput.setVisibility(View.INVISIBLE);
        editTextInput.setVisibility(View.INVISIBLE);
        seekWord.setVisibility(View.INVISIBLE);
        imageViewBackground.setVisibility(View.INVISIBLE);


        runTimer();
        buildSeekBar();
        checkUpdatedInput();
    }

    public void checkUpdatedInput()
    {
        editTextInput.addTextChangedListener(new TextWatcher(){
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                //
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String text = editTextInput.getText().toString();
                if (text.startsWith(" ")) {
                    editTextInput.setText(text.trim());
                }
                numWords();
                updateSeekBar();
                showText();
            }

            @Override
            public void afterTextChanged(Editable editable) {
                //
            }
        });
    }

    public void numWords()
    {
        num = (editTextInput.getText().toString()).split("\\s+");
        numWords = num.length;
    }

    public void updateSeekBar()
    {
        if(numWords != 0)
        {
            seekWord.setMax(numWords-1);
        }
        else
        {
            seekWord.setMax(0);
        }
    }

    public void showText()
    {
        textViewOutput.setText("Word "+(seekWord.getProgress()+1)+": "+num[seekWord.getProgress()]);
    }

    public void buildSeekBar()
    {
        updateSeekBar();
        seekWord.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b)
            {
                showText();
                Log.i("Time", String.valueOf(seekWord.getProgress()));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekbar)
            {
                //
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekbar)
            {
                //
            }
        });
    }

    public void runTimer()
    {
        seekWord = findViewById(R.id.seekBarChooseWord);
        new CountDownTimer(4000, 1000 )
        {
            @Override
            public void onTick(long l)
            {
                //
            }
            @Override
            public void onFinish()
            {
                textViewOutput.setVisibility(View.VISIBLE);
                editTextInput.setVisibility(View.VISIBLE);
                seekWord.setVisibility(View.VISIBLE);
                imageViewSplash.setVisibility(View.INVISIBLE);
            }
        }.start();
    }
}
